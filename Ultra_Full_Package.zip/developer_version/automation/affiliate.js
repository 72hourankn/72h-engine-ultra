// affiliate helper placeholder
