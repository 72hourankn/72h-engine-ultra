// create-checkout-session placeholder
