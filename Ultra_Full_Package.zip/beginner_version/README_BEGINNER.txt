Beginner Version - Quick Start
This folder contains a simple static site (index.html, styles.css, script.js). Use Vercel to deploy as a static site.
