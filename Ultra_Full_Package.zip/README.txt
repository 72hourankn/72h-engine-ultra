Ultra Full Package (Beginner + Developer) - deploy using DEPLOY_GUIDE.txt
